<?php 
session_start();
 include '../konek.php'; // untuk mengambil koneksi ke db

$a = $_GET['h']; // 32
$jumlah = $_GET['jumlah']; // jumlah

$queri = mysqli_query($koneksi,"SELECT * FROM barang_tersedia where id_masuk='".$a."' "); // query menambahkan data ke tabel 

while ($rs = mysqli_fetch_array($queri)) {
	$awal = $rs['jumlah_tersedia'];
	$akhir = $awal-$_GET['jumlah'];
	// echo "UPDATE barang_tersedia set jumlah_tersedia='".$akhir."' where id_tersedia='".$rs['id_tersedia']."'";
	$simpan = mysqli_query($koneksi,"UPDATE barang_tersedia set jumlah_tersedia='".$akhir."' where id_tersedia='".$rs['id_tersedia']."'"); // query menambahkan data ke tabel 
	if ($simpan) {
	    header("Location: http://localhost/persediaan/view/main/index.php?h=penjualan&save=0");
	} else {
	    header("Location: http://localhost/persediaan/view/main/index.php?h=penjualan&save=1");
	}

}



?>
<?php 
session_start();
 include '../konek.php'; // untuk mengambil koneksi ke db

$a = $_GET['h'];

$queri = mysqli_query($koneksi,"SELECT * FROM barang_masuk where nama_barang='".$a."' GROUP BY nama_barang ORDER BY id_masuk ASC"); // query menambahkan data ke tabel 
// echo "SELECT * FROM barang_masuk where nama_barang='".$a."' GROUP BY nama_barang ORDER BY id_masuk ASC";
while ($rs = mysqli_fetch_array($queri)) {

		$lihat = mysqli_query($koneksi,"SELECT * from barang_tersedia where id_masuk='".$rs['id_masuk']."'"); // query menambahkan data ke tabel 

			if (mysqli_num_rows($lihat)=="0") { 

					$simpan = mysqli_query($koneksi,"INSERT INTO barang_tersedia VALUES ('','".$rs['id_masuk']."','".$rs['jumlah_masuk']."')"); // query menambahkan data ke tabel 
					if ($simpan) {
					    header("Location: http://localhost/persediaan/view/main/index.php?h=pembelian&save=0");
					} else {
					    header("Location: http://localhost/persediaan/view/main/index.php?h=pembelian&save=1");
					}
			}else{
				while ($rsl = mysqli_fetch_array($lihat)) {
					$awal = $rsl['jumlah_tersedia'];
					$akhir = $awal+$_GET['jumlah'];
					$simpan = mysqli_query($koneksi,"UPDATE barang_tersedia set jumlah_tersedia='".$akhir."' where id_tersedia='".$rsl['id_tersedia']."'"); // query menambahkan data ke tabel 
					if ($simpan) {
					    header("Location: http://localhost/persediaan/view/main/index.php?h=pembelian&save=0");
					} else {
					    header("Location: http://localhost/persediaan/view/main/index.php?h=pembelian&save=1");
					}
				}
			}
}



?>
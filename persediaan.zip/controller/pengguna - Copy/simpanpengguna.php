<?php 
 include '../konek.php'; // untuk mengambil koneksi ke db

	// query untuk mengecek username sudah ada di dalam data base apa belum
	$cekpengguna = mysqli_query($koneksi,"select * from pengguna where username='".$_POST['username']."'"); 


	// mysqli_num_rows = untuk menghitung jumlah data yang ada di query cek pengguna diatas, jika ada maka nilainya lebih dari 0, jika tidak ada maka nilainya 0
	// kita cek apakah username di db ada yang sama atau tidak, jika ada yang sama masuk ke else
	if (mysqli_num_rows($cekpengguna)=="0") { 

		if ($_POST['id_pengguna']=="") {
			$queri = mysqli_query($koneksi,"INSERT INTO pengguna VALUES ('','".$_POST['username']."','".md5($_POST['password'])."','".$_POST['jabatan']."')");
		}else{
			$queri = mysqli_query($koneksi,"UPDATE pengguna SET 
				'username'='1', 
				'password'='2', 
				'jabatan'='3' 
				where id=".$_POST['id_pengguna']."");
		}



		if ($queri) {
			$response = [
				"success" => true, 
				"title" => "Success", 
				"text" => "Berhasil menyimpan data" 
			];
		} else {
			$response = [
				"success" => false, 
				"title" => "Error", 
				"text" => "Gagal menyimpan data" 
			];
		}

	}else{
		$response = [
				"success" => false, 
				"title" => "Error", 
				"text" => "User Name Sudah Digunakan" 
			];
	}

		echo json_encode($queri);
?>
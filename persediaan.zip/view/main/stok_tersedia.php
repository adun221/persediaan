<?php 
  if (isset($_SESSION['status']) == "login") {
  }else{
    header("Location: http://localhost/persediaan");
  }

?>
        <div class="container-fluid">
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Barang Tersedia</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width: 50px;">No</th>
                      <th>Nama Barang</th>
                      <th>Stok</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $n = "0";
                       $query = mysqli_query($koneksi,"SELECT a.*,b.nama_barang FROM barang_tersedia a JOIN barang_masuk b ON a.id_masuk=b.id_masuk WHERE a.jumlah_tersedia!=0 ");
                       while ($rs = mysqli_fetch_array($query)) { $n++; ?>
                        <tr>
                          <td><?=$n;?></td>
                          <td><?=$rs['nama_barang'];?></td>
                          <td><?=$rs['jumlah_tersedia'];?></td>
                        </tr>
                       <?php }
                       ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>




<!--         <div class="container-fluid">
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Barang Tersedia</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th style="width: 50px;">No</th>
                      <th>Nama Barang</th>
                      <th>Jumlah Barang Masuk</th>
                      <th>Jumlah Barang Keluar</th>
                      <th>Stok</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $n = "0";
                       $query = mysqli_query($koneksi,"SELECT a.nama_barang, a.jumlah_masuk, b.jumlah_keluar, (a.jumlah_masuk-b.jumlah_keluar) AS stok FROM (SELECT id_masuk, nama_barang,SUM(jumlah_masuk) AS jumlah_masuk FROM barang_masuk GROUP BY nama_barang) a JOIN (SELECT id_masuk, SUM(jumlah_keluar) AS jumlah_keluar FROM barang_keluar GROUP BY id_masuk) b ON a.id_masuk=b.id_masuk order by a.nama_barang ASC ");
                       while ($rs = mysqli_fetch_array($query)) { $n++; ?>
                        <tr>
                          <td><?=$n;?></td>
                          <td><?=$rs['nama_barang'];?></td>
                          <td><?=$rs['jumlah_masuk'];?></td>
                          <td><?=$rs['jumlah_keluar'];?></td>
                          <td><?=$rs['stok'];?></td>
                        </tr>
                       <?php }
                       ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div> -->